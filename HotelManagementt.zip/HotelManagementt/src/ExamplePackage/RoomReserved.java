package ExamplePackage;

public class RoomReserved {
	  String todate ;
	  String roomtype;
      String fromdate ;
      int vehicleprice ;
      int roomprice ;
      int mealprice ;
      int totalprice;
      String roomid,username ;
	public String getTodate() {
		return todate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public String getFromdate() {
		return fromdate;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public int getVehicleprice() {
		return vehicleprice;
	}
	public void setVehicleprice(int vehicleprice) {
		this.vehicleprice = vehicleprice;
	}
	public int getRoomprice() {
		return roomprice;
	}
	public void setRoomprice(int roomprice) {
		this.roomprice = roomprice;
	}
	public int getMealprice() {
		return mealprice;
	}
	public void setMealprice(int mealprice) {
		this.mealprice = mealprice;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
      
      
}
